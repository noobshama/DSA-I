#include<bits/stdc++.h>
using namespace std;
set<pair<int,int>>points;
int detSide(pair<int,int>leftPoint,pair<int,int>rightPoint,pair<int,int>point)
{
    int p=((point.second-leftPoint.second)*(rightPoint.first-leftPoint.first)-(rightPoint.second-leftPoint.second)*(point.first-leftPoint.first));
    if(p>0)
    {
        return 1;
    }
    if(p<0)
    {
        return -1;
    }
    return 0;
}
int detDist(pair<int,int>leftPoint,pair<int,int>rightPoint,pair<int,int>point)
{
    int dist=abs((point.second-leftPoint.second)*(rightPoint.first-leftPoint.first)-(rightPoint.second-leftPoint.second)*(point.first-leftPoint.first));
    return dist;
}
void detPointsInConvexPolygon(vector<pair<int,int>>convexPolygon,pair<int,int>leftPoint,pair<int,int>rightPoint,int bound)
{
  int interval=-1;
  int maxDist=0;
  for(int i=0;i<convexPolygon.size();i++)
  {
    int tempDist=detDist(leftPoint,rightPoint,convexPolygon[i]);
    if (detSide(leftPoint,rightPoint,convexPolygon[i])==bound&&tempDist>maxDist) 
    {
       interval=i;
       maxDist=tempDist;
    }
  }   
  if(interval==-1)
  {
    if(points.find(leftPoint)==points.end())
    {
        points.insert(leftPoint);
    }
    if(points.find(rightPoint)==points.end())
    {
        points.insert(rightPoint);
    }
    return ;
  }
  detPointsInConvexPolygon(convexPolygon,convexPolygon[interval],leftPoint,-detSide(convexPolygon[interval],leftPoint,rightPoint));
  detPointsInConvexPolygon(convexPolygon,convexPolygon[interval],rightPoint,-detSide(convexPolygon[interval], rightPoint,leftPoint));
}
void  pointsOfConvexPolygon(vector<pair<int,int>>convexPolygon)
{
    int minX=0,maxX=0;
    for(int i=1;i<convexPolygon.size();i++)
    {
        if(convexPolygon[i].first<convexPolygon[minX].first)
        {
            minX=i;
        }
        if(convexPolygon[i].first>convexPolygon[maxX].first)
        {
            maxX=i;
        }
    }
    detPointsInConvexPolygon(convexPolygon,convexPolygon[minX],convexPolygon[maxX],1);
    detPointsInConvexPolygon(convexPolygon,convexPolygon[minX],convexPolygon[maxX],-1);
    ofstream outfile("out.txt");
    outfile.clear();
    for(auto p:points)
    {
        outfile<<p.first<<" "<<p.second<<endl;
    }
    points.clear();
    outfile.close();
    
}
int main()
{
    ifstream infile("in3.txt"); 
    int N;
    infile>>N;
    vector<pair<int,int>>convexPolygon(N);
    for(int i=0;i<N;i++)
    {
        infile>>convexPolygon[i].first>>convexPolygon[i].second;
        
    }
    pointsOfConvexPolygon(convexPolygon);
        return 0;
}