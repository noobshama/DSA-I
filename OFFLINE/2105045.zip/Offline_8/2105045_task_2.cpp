#include<bits/stdc++.h>
using namespace std;

int minimumNumberOfPlateforms(vector<int>arrival,vector<int>departure,int N) 
{
    sort(arrival.begin(),arrival.end());
    sort(departure.begin(),departure.end());
    int platforms = 1,count = 1;
    int i=1,j=0;
    while(i<N) 
    {
        if(arrival[i]<=departure[j]) 
        {
            count++;
            i++;
            platforms=max(count,platforms);
        } 
        else if(arrival[i]>departure[j])
        {
            count--;
            j++;
        }
    }

    return platforms;
}

int main() {
    ifstream infile("in_1.txt");
    int N;
    infile >> N;
    vector<int>arrival(N),departure(N);
    for (int i= 0;i<N;i++) {
        infile>>arrival[i]>>departure[i];
    }
    int minimumPlateforms = minimumNumberOfPlateforms(arrival, departure, N);
    ofstream outfile("out.txt");
    outfile.clear();
    outfile<<minimumPlateforms<<endl;
    outfile.close();
    return 0;
}
